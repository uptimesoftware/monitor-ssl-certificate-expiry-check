/usr/bin/php -q MonitorCertificateExpiry.php $*
